
import React from 'react';
import './App.css';

function App() {
  return (
    <main className="min-h-screen bg-cream text-charcoal p-6">
      <nav className="flex justify-between items-center mb-10">
        <img src="/logo.png" alt="Clean Cweens Logo" className="w-24" />
        <ul className="flex gap-6 font-semibold">
          <li><a href="#services" className="hover:underline">Services</a></li>
          <li><a href="#booking" className="hover:underline">Book</a></li>
          <li><a href="#contact" className="hover:underline">Contact</a></li>
        </ul>
      </nav>

      <section className="text-center py-10">
        <h1 className="text-4xl font-bold mb-2">Welcome to Clean Cweens</h1>
        <p className="text-lg">Luxury cleaning at affordable rates – because queens deserve clean.</p>
        <button className="mt-6 px-6 py-3 bg-gold text-white font-semibold rounded-xl shadow-md">
          Book Your Clean
        </button>
      </section>

      <section id="services" className="grid gap-8 md:grid-cols-3 text-left mt-10">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Residential Cleaning</h2>
          <p>Deep cleans, regular upkeep, and move-in/move-out services for every space.</p>
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-2">Commercial Cleaning</h2>
          <p>Offices, salons, and retail spaces – sparkling clean, every time.</p>
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-2">Airbnb & Short-Term Rentals</h2>
          <p>Fast turnarounds with professional attention to detail and reliability.</p>
        </div>
      </section>

      <section id="booking" className="mt-16 text-center">
        <h2 className="text-3xl font-bold mb-4">Let’s Keep It Clean</h2>
        <p className="mb-6">Book your cleaning service now – quick and easy.</p>
        <form
          className="max-w-md mx-auto space-y-4"
          method="POST"
          action="https://formspree.io/f/your-placeholder-id"
        >
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            className="w-full p-3 rounded-lg border border-gray-300"
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Your Email"
            className="w-full p-3 rounded-lg border border-gray-300"
            required
          />
          <select name="service" className="w-full p-3 rounded-lg border border-gray-300" required>
            <option value="">Select Cleaning Type</option>
            <option value="residential">Residential Cleaning</option>
            <option value="commercial">Commercial Cleaning</option>
            <option value="airbnb">Airbnb/Short-Term Rental</option>
          </select>
          <input
            type="date"
            name="date"
            className="w-full p-3 rounded-lg border border-gray-300"
            required
          />
          <input
            type="time"
            name="time"
            className="w-full p-3 rounded-lg border border-gray-300"
            required
          />
          <textarea
            name="message"
            placeholder="Additional Details (optional)"
            className="w-full p-3 rounded-lg border border-gray-300"
          ></textarea>
          <button type="submit" className="w-full bg-charcoal text-white py-3 rounded-xl font-bold">
            Submit Booking Request
          </button>
        </form>
      </section>

      <section className="mt-16">
        <h2 className="text-3xl font-bold text-center mb-6">Client Testimonials</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p>“Clean Cweens made my home sparkle like never before! Reliable and affordable.”</p>
            <p className="mt-2 font-semibold">– Jasmine R.</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p>“Professional, punctual, and thorough. I highly recommend their services!”</p>
            <p className="mt-2 font-semibold">– Marco T.</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p>“They handled my Airbnb turnover perfectly – every detail was spotless!”</p>
            <p className="mt-2 font-semibold">– Alexis M.</p>
          </div>
        </div>
      </section>

      <section className="mt-16">
        <h2 className="text-3xl font-bold text-center mb-6">Before & After</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-xl font-semibold mb-2">Kitchen Deep Clean</h3>
            <img src="/images/kitchen-before.jpg" alt="Before - Kitchen" className="rounded-lg shadow-md mb-2" />
            <img src="/images/kitchen-after.jpg" alt="After - Kitchen" className="rounded-lg shadow-md" />
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Bathroom Refresh</h3>
            <img src="/images/bathroom-before.jpg" alt="Before - Bathroom" className="rounded-lg shadow-md mb-2" />
            <img src="/images/bathroom-after.jpg" alt="After - Bathroom" className="rounded-lg shadow-md" />
          </div>
        </div>
      </section>

      <section id="contact" className="mt-16 text-center">
        <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
        <p>Email: clean@cleancweens.com (placeholder)</p>
        <p>Phone: (123) 456-7890 (placeholder)</p>
        <p>Charlotte, NC</p>
      </section>
    </main>
  );
}

export default App;
